import React, { useState, useEffect } from 'react';
import { locationAPI } from '../services/api';
import LocationCard from '../components/locations/LocationCard';

interface Location {
  _id: string;
  name: string;
  image: string;
  address: string;
  phone: string;
  email: string;
  hours: {
    weekdays: string;
    saturday: string;
    sunday: string;
  };
}

const LocationsPage: React.FC = () => {
  const [locations, setLocations] = useState<Location[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchLocations = async () => {
      try {
        setLoading(true);
        const response = await locationAPI.getAllLocations();
        setLocations(response.data);
        setError(null);
      } catch (err) {
        console.error('Failed to fetch locations:', err);
        setError('Failed to load locations. Please try again later.');
        // Fallback to placeholder data if API fails
        setLocations(getPlaceholderLocations());
      } finally {
        setLoading(false);
      }
    };

    fetchLocations();
  }, []);

  // Placeholder data for fallback
  const getPlaceholderLocations = (): Location[] => {
    return [
      {
        _id: '1',
        name: 'Pretoria Office',
        image: 'https://images.unsplash.com/photo-1577948000111-9c970dfe3743?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
        address: '123 Church Street, Pretoria Central, 0002',
        phone: '+27 12 345 6789',
        email: 'pretoria@vhambalogistics.co.za',
        hours: {
          weekdays: '7:00 AM - 7:00 PM',
          saturday: '8:00 AM - 5:00 PM',
          sunday: '9:00 AM - 4:00 PM',
        },
      },
      {
        _id: '2',
        name: 'Cape Town Office',
        image: 'https://images.unsplash.com/photo-1580060839134-75a5edca2e99?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
        address: '456 Long Street, Cape Town City Centre, 8001',
        phone: '+27 21 987 6543',
        email: 'capetown@vhambalogistics.co.za',
        hours: {
          weekdays: '7:00 AM - 7:00 PM',
          saturday: '8:00 AM - 5:00 PM',
          sunday: '9:00 AM - 4:00 PM',
        },
      },
    ];
  };

  return (
    <div>
      <section className="py-16 md:py-24 bg-light-blue">
        <div className="container mx-auto px-4">
          <h2 className="section-title">
            <span>Our</span> <span>Locations</span>
          </h2>
          <p className="section-description">
            Visit our conveniently located offices in Pretoria and Cape Town for personalized service and vehicle inspections.
          </p>
          
          {/* Loading and Error States */}
          {loading && (
            <div className="text-center py-12">
              <div className="inline-block animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary-blue"></div>
              <p className="mt-2 text-gray-600">Loading locations...</p>
            </div>
          )}
          
          {error && !loading && (
            <div className="text-center py-12">
              <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
                <strong className="font-bold">Error: </strong>
                <span className="block sm:inline">{error}</span>
              </div>
            </div>
          )}
          
          {!loading && !error && (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
              {locations.map(location => (
                <LocationCard 
                  key={location._id}
                  name={location.name}
                  image={location.image}
                  address={location.address}
                  phone={location.phone}
                  email={location.email}
                  hours={location.hours}
                />
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
};

export default LocationsPage;
