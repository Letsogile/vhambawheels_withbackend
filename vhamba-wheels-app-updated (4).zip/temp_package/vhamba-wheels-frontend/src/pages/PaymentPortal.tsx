import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { paymentService } from '../services/api';

// Payment Type Options
const PAYMENT_TYPES = [
  { id: 'lease_payment', label: 'Lease Payment' },
  { id: 'deposit', label: 'Security Deposit' },
  { id: 'maintenance', label: 'Maintenance Fee' },
  { id: 'insurance', label: 'Insurance Premium' },
  { id: 'other', label: 'Other Payment' }
];

const PaymentPortal = () => {
  const [formData, setFormData] = useState({
    paymentType: '',
    vehicleId: '',
    amount: '',
    cardholderName: '',
    cardNumber: '',
    expiryDate: '',
    cvv: ''
  });
  const [errors, setErrors] = useState({});
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [paymentSuccess, setPaymentSuccess] = useState(false);
  const [paymentError, setPaymentError] = useState(null);
  const navigate = useNavigate();

  // Calculate processing fee and total
  const amount = parseFloat(formData.amount) || 0;
  const processingFee = amount > 0 ? 5.00 : 0;
  const total = amount + processingFee;

  const handleChange = (e) => {
    const { name, value } = e.target;
    
    // Format card number with spaces
    if (name === 'cardNumber') {
      const formattedValue = value
        .replace(/\s/g, '')
        .replace(/(\d{4})/g, '$1 ')
        .trim();
      
      setFormData(prev => ({
        ...prev,
        [name]: formattedValue
      }));
      return;
    }
    
    // Format expiry date with slash
    if (name === 'expiryDate') {
      let formattedValue = value.replace(/\D/g, '');
      if (formattedValue.length > 2) {
        formattedValue = `${formattedValue.slice(0, 2)}/${formattedValue.slice(2, 4)}`;
      }
      
      setFormData(prev => ({
        ...prev,
        [name]: formattedValue
      }));
      return;
    }
    
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const validateForm = () => {
    const newErrors = {};
    
    if (!formData.paymentType) newErrors.paymentType = 'Payment type is required';
    if (!formData.amount) newErrors.amount = 'Amount is required';
    else if (isNaN(formData.amount) || parseFloat(formData.amount) <= 0) {
      newErrors.amount = 'Please enter a valid amount';
    }
    
    if (!formData.cardholderName) newErrors.cardholderName = 'Cardholder name is required';
    
    if (!formData.cardNumber) newErrors.cardNumber = 'Card number is required';
    else if (!/^\d{4}\s\d{4}\s\d{4}\s\d{4}$/.test(formData.cardNumber)) {
      newErrors.cardNumber = 'Please enter a valid 16-digit card number';
    }
    
    if (!formData.expiryDate) newErrors.expiryDate = 'Expiry date is required';
    else if (!/^\d{2}\/\d{2}$/.test(formData.expiryDate)) {
      newErrors.expiryDate = 'Please enter a valid expiry date (MM/YY)';
    }
    
    if (!formData.cvv) newErrors.cvv = 'CVV is required';
    else if (!/^\d{3,4}$/.test(formData.cvv)) {
      newErrors.cvv = 'Please enter a valid CVV';
    }
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    
    if (!validateForm()) {
      return;
    }
    
    setIsSubmitting(true);
    setPaymentError(null);
    
    try {
      // Prepare payment data for API
      const paymentData = {
        paymentType: formData.paymentType,
        vehicleId: formData.vehicleId || undefined,
        amount: parseFloat(formData.amount),
        cardholderName: formData.cardholderName,
        cardNumber: formData.cardNumber.replace(/\s/g, ''),
        expiryDate: formData.expiryDate,
        cvv: formData.cvv
      };
      
      // Call API to process payment
      await paymentService.processPayment(paymentData);
      
      setPaymentSuccess(true);
      // Redirect to success page or home page after successful payment
      setTimeout(() => {
        navigate('/');
      }, 3000);
    } catch (error) {
      console.error('Payment processing failed:', error);
      setPaymentError(typeof error === 'string' ? error : 'Failed to process payment. Please check your card details and try again.');
    } finally {
      setIsSubmitting(false);
    }
  };

  return (
    <div className="py-16 md:py-24">
      <div className="container mx-auto px-4">
        <h1 className="text-4xl font-bold text-center text-primary-blue mb-4">Payment Portal</h1>
        <p className="text-center text-gray-600 mb-12">
          Secure payment processing for Vhamba Logistics contractors
        </p>
        
        {paymentSuccess ? (
          <div className="bg-green-100 border border-green-400 text-green-700 px-6 py-4 rounded-lg text-center max-w-3xl mx-auto">
            <h2 className="text-2xl font-bold mb-2">Payment Processed Successfully!</h2>
            <p>Your payment has been processed. A confirmation email will be sent to your registered email address.</p>
            <p className="mt-4">Redirecting to home page...</p>
          </div>
        ) : (
          <div className="grid grid-cols-1 lg:grid-cols-3 gap-8 max-w-6xl mx-auto">
            <div className="lg:col-span-2">
              <div className="bg-white rounded-lg shadow-md p-6 md:p-8">
                {paymentError && (
                  <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
                    <p>{paymentError}</p>
                  </div>
                )}
                
                {isSubmitting ? (
                  <div className="text-center py-12">
                    <div className="inline-block animate-spin rounded-full h-12 w-12 border-t-2 border-b-2 border-primary-blue mb-4"></div>
                    <p className="text-xl">Processing your payment...</p>
                  </div>
                ) : (
                  <div>
                    <h2 className="text-2xl font-bold mb-4">Payment Information</h2>
                    <p className="text-gray-600 mb-6">Enter your payment details securely</p>
                    
                    <form onSubmit={handleSubmit} className="space-y-4">
                      <div>
                        <label htmlFor="paymentType" className="block text-gray-700 mb-2">
                          Payment Type
                        </label>
                        <select
                          id="paymentType"
                          name="paymentType"
                          value={formData.paymentType}
                          onChange={handleChange}
                          className={`w-full p-3 border ${errors.paymentType ? 'border-red-500' : 'border-gray-300'} rounded-md focus:outline-none focus:ring-2 focus:ring-primary-blue`}
                          disabled={isSubmitting}
                        >
                          <option value="">Select payment type</option>
                          {PAYMENT_TYPES.map(type => (
                            <option key={type.id} value={type.id}>{type.label}</option>
                          ))}
                        </select>
                        {errors.paymentType && <p className="text-red-500 text-sm mt-1">{errors.paymentType}</p>}
                      </div>
                      
                      <div>
                        <label htmlFor="vehicleId" className="block text-gray-700 mb-2">
                          Vehicle ID (if applicable)
                        </label>
                        <input
                          type="text"
                          id="vehicleId"
                          name="vehicleId"
                          placeholder="Enter vehicle ID"
                          value={formData.vehicleId}
                          onChange={handleChange}
                          className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-blue"
                          disabled={isSubmitting}
                        />
                      </div>
                      
                      <div>
                        <label htmlFor="amount" className="block text-gray-700 mb-2">
                          Amount (ZAR)
                        </label>
                        <div className="relative">
                          <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">R</span>
                          <input
                            type="text"
                            id="amount"
                            name="amount"
                            placeholder="0.00"
                            value={formData.amount}
                            onChange={handleChange}
                            className={`w-full p-3 pl-8 border ${errors.amount ? 'border-red-500' : 'border-gray-300'} rounded-md focus:outline-none focus:ring-2 focus:ring-primary-blue`}
                            disabled={isSubmitting}
                          />
                        </div>
                        {errors.amount && <p className="text-red-500 text-sm mt-1">{errors.amount}</p>}
                      </div>
                      
                      <div>
                        <label htmlFor="cardholderName" className="block text-gray-700 mb-2">
                          Cardholder Name
                        </label>
                        <input
                          type="text"
                          id="cardholderName"
                          name="cardholderName"
                          placeholder="John Doe"
                          value={formData.cardholderName}
                          onChange={handleChange}
                          className={`w-full p-3 border ${errors.cardholderName ? 'border-red-500' : 'border-gray-300'} rounded-md focus:outline-none focus:ring-2 focus:ring-primary-blue`}
                          disabled={isSubmitting}
                        />
                        {errors.cardholderName && <p className="text-red-500 text-sm mt-1">{errors.cardholderName}</p>}
                      </div>
                      
                      <div>
                        <label htmlFor="cardNumber" className="block text-gray-700 mb-2">
                          Card Number
                        </label>
                        <div className="relative">
                          <span className="absolute left-3 top-1/2 transform -translate-y-1/2 text-gray-500">
                            <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5" viewBox="0 0 20 20" fill="currentColor">
                              <path d="M4 4a2 2 0 00-2 2v1h16V6a2 2 0 00-2-2H4z" />
                              <path fillRule="evenodd" d="M18 9H2v5a2 2 0 002 2h12a2 2 0 002-2V9zM4 13a1 1 0 011-1h1a1 1 0 110 2H5a1 1 0 01-1-1zm5-1a1 1 0 100 2h1a1 1 0 100-2H9z" clipRule="evenodd" />
                            </svg>
                          </span>
                          <input
                            type="text"
                            id="cardNumber"
                            name="cardNumber"
                            placeholder="1234 5678 9012 3456"
                            value={formData.cardNumber}
                            onChange={handleChange}
                            maxLength={19}
                            className={`w-full p-3 pl-10 border ${errors.cardNumber ? 'border-red-500' : 'border-gray-300'} rounded-md focus:outline-none focus:ring-2 focus:ring-primary-blue`}
                            disabled={isSubmitting}
                          />
                        </div>
                        {errors.cardNumber && <p className="text-red-500 text-sm mt-1">{errors.cardNumber}</p>}
                      </div>
                      
                      <div className="grid grid-cols-2 gap-4">
                        <div>
                          <label htmlFor="expiryDate" className="block text-gray-700 mb-2">
                            Expiry Date
                          </label>
                          <input
                            type="text"
                            id="expiryDate"
                            name="expiryDate"
                            placeholder="MM/YY"
                            value={formData.expiryDate}
                            onChange={handleChange}
                            maxLength={5}
                            className={`w-full p-3 border ${errors.expiryDate ? 'border-red-500' : 'border-gray-300'} rounded-md focus:outline-none focus:ring-2 focus:ring-primary-blue`}
                            disabled={isSubmitting}
                          />
                          {errors.expiryDate && <p className="text-red-500 text-sm mt-1">{errors.expiryDate}</p>}
                        </div>
                        
                        <div>
                          <label htmlFor="cvv" className="block text-gray-700 mb-2">
                            CVV
                          </label>
                          <input
                            type="text"
                            id="cvv"
                            name="cvv"
                            placeholder="123"
                            value={formData.cvv}
                            onChange={handleChange}
                            maxLength={4}
                            className={`w-full p-3 border ${errors.cvv ? 'border-red-500' : 'border-gray-300'} rounded-md focus:outline-none focus:ring-2 focus:ring-primary-blue`}
                            disabled={isSubmitting}
                          />
                          {errors.cvv && <p className="text-red-500 text-sm mt-1">{errors.cvv}</p>}
                        </div>
                      </div>
                      
                      <div className="mt-6">
                        <button
                          type="submit"
                          className="w-full bg-gradient-to-r from-primary-blue to-primary-teal text-white font-bold py-3 px-6 rounded-md hover:opacity-90 transition-opacity flex items-center justify-center"
                          disabled={isSubmitting}
                        >
                          {isSubmitting ? (
                            <>
                              <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                                <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                                <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                              </svg>
                              Processing...
                            </>
                          ) : (
                            <>
                              <svg xmlns="http://www.w3.org/2000/svg" className="h-5 w-5 mr-2" viewBox="0 0 20 20" fill="currentColor">
                                <path fillRule="evenodd" d="M5 9V7a5 5 0 0110 0v2a2 2 0 012 2v5a2 2 0 01-2 2H5a2 2 0 01-2-2v-5a2 2 0 012-2zm8-2v2H7V7a3 3 0 016 0z" clipRule="evenodd" />
                              </svg>
                              Process Secure Payment
                            </>
                          )}
                        </button>
                      </div>
                      
                      <p className="text-center text-sm text-gray-500 mt-4">
                        Your payment information is encrypted and secure
                      </p>
                    </form>
                  </div>
                )}
              </div>
            </div>
            
            <div>
              <div className="bg-white rounded-lg shadow-md p-6 md:p-8 mb-6">
                <h2 className="text-xl font-bold mb-4">Payment Summary</h2>
                <div className="space-y-3">
                  <div className="flex justify-between">
                    <span className="text-gray-600">Payment Type:</span>
                    <span className="font-medium">
                      {formData.paymentType ? 
                        PAYMENT_TYPES.find(t => t.id === formData.paymentType)?.label : 
                        'Not selected'}
                    </span>
                  </div>
                  
                  <div className="flex justify-between">
                    <span className="text-gray-600">Amount:</span>
                    <span className="font-medium">R {amount.toFixed(2)}</span>
                  </div>
                  
                  <div className="flex justify-between">
                    <span className="text-gray-600">Processing Fee:</span>
                    <span className="font-medium">R {processingFee.toFixed(2)}</span>
                  </div>
                  
                  <div className="border-t border-gray-200 pt-3 mt-3">
                    <div className="flex justify-between font-bold">
                      <span>Total:</span>
                      <span className="text-primary-blue">R {total.toFixed(2)}</span>
                    </div>
                  </div>
                </div>
              </div>
              
              <div className="bg-white rounded-lg shadow-md p-6 md:p-8">
                <h2 className="text-xl font-bold mb-4">Payment Methods Accepted</h2>
                <div className="grid grid-cols-2 gap-4">
                  <div className="border border-gray-200 rounded-md p-4 text-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 mx-auto mb-2 text-blue-600" viewBox="0 0 20 20" fill="currentColor">
                      <path d="M4 4a2 2 0 00-2 2v1h16V6a2 2 0 00-2-2H4z" />
                      <path fillRule="evenodd" d="M18 9H2v5a2 2 0 002 2h12a2 2 0 002-2V9zM4 13a1 1 0 011-1h1a1 1 0 110 2H5a1 1 0 01-1-1zm5-1a1 1 0 100 2h1a1 1 0 100-2H9z" clipRule="evenodd" />
                    </svg>
                    <div className="font-medium">Credit Cards</div>
                    <div className="text-xs text-gray-500">Visa, Mastercard</div>
                  </div>
                  
                  <div className="border border-gray-200 rounded-md p-4 text-center">
                    <svg xmlns="http://www.w3.org/2000/svg" className="h-8 w-8 mx-auto mb-2 text-green-600" viewBox="0 0 20 20" fill="currentColor">
                      <path fillRule="evenodd" d="M4 4a2 2 0 00-2 2v4a2 2 0 002 2V6h10a2 2 0 00-2-2H4zm2 6a2 2 0 012-2h8a2 2 0 012 2v4a2 2 0 01-2 2H8a2 2 0 01-2-2v-4zm6 4a2 2 0 100-4 2 2 0 000 4z" clipRule="evenodd" />
                    </svg>
                    <div className="font-medium">Bank Transfer</div>
                    <div className="text-xs text-gray-500">Direct deposit</div>
                  </div>
                </div>
                
                <div className="mt-6">
                  <h3 className="font-bold mb-2">Need Help?</h3>
                  <div className="space-y-2 text-sm">
                    <p><span className="font-medium">Payment Issues:</span> +27 12 345 6789</p>
                    <p><span className="font-medium">Technical Support:</span> support@vhambalogistics.co.za</p>
                    <p><span className="font-medium">Business Hours:</span> Mon-Fri 8AM-6PM</p>
                  </div>
                </div>
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};

export default PaymentPortal;
