import React, { useState } from 'react';
import { useNavigate } from 'react-router-dom';
import { driverService } from '../services/api';

// Step indicators component
const StepIndicator = ({ currentStep, totalSteps }) => {
  return (
    <div className="flex justify-center mb-8">
      {Array.from({ length: totalSteps }).map((_, index) => (
        <div key={index} className="flex items-center">
          <div 
            className={`w-10 h-10 rounded-full flex items-center justify-center text-white font-bold ${
              index + 1 === currentStep 
                ? 'bg-primary-blue' 
                : index + 1 < currentStep 
                  ? 'bg-primary-blue' 
                  : 'bg-gray-300'
            }`}
          >
            {index + 1}
          </div>
          {index < totalSteps - 1 && (
            <div 
              className={`h-1 w-16 ${
                index + 1 < currentStep ? 'bg-primary-blue' : 'bg-gray-300'
              }`}
            ></div>
          )}
        </div>
      ))}
    </div>
  );
};

// Personal Information Form (Step 1)
const PersonalInfoForm = ({ formData, setFormData, onNext }) => {
  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const validateForm = () => {
    const newErrors = {};
    if (!formData.firstName?.trim()) newErrors.firstName = 'First name is required';
    if (!formData.lastName?.trim()) newErrors.lastName = 'Last name is required';
    if (!formData.email?.trim()) newErrors.email = 'Email is required';
    else if (!/\S+@\S+\.\S+/.test(formData.email)) newErrors.email = 'Email is invalid';
    if (!formData.phone?.trim()) newErrors.phone = 'Phone number is required';
    if (!formData.idNumber?.trim()) newErrors.idNumber = 'ID number is required';
    if (!formData.address?.trim()) newErrors.address = 'Physical address is required';
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setIsLoading(true);
    
    if (validateForm()) {
      // In a real app, we might validate email uniqueness here
      setTimeout(() => {
        setIsLoading(false);
        onNext();
      }, 500);
    } else {
      setIsLoading(false);
    }
  };

  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Personal Information</h2>
      <p className="text-gray-600 mb-6">Please provide your basic personal information</p>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
          <div>
            <label htmlFor="firstName" className="block text-gray-700 mb-2">
              First Name *
            </label>
            <input
              type="text"
              id="firstName"
              name="firstName"
              value={formData.firstName || ''}
              onChange={handleChange}
              className={`w-full p-3 border ${errors.firstName ? 'border-red-500' : 'border-gray-300'} rounded-md focus:outline-none focus:ring-2 focus:ring-primary-blue`}
              disabled={isLoading}
            />
            {errors.firstName && <p className="text-red-500 text-sm mt-1">{errors.firstName}</p>}
          </div>
          
          <div>
            <label htmlFor="lastName" className="block text-gray-700 mb-2">
              Last Name *
            </label>
            <input
              type="text"
              id="lastName"
              name="lastName"
              value={formData.lastName || ''}
              onChange={handleChange}
              className={`w-full p-3 border ${errors.lastName ? 'border-red-500' : 'border-gray-300'} rounded-md focus:outline-none focus:ring-2 focus:ring-primary-blue`}
              disabled={isLoading}
            />
            {errors.lastName && <p className="text-red-500 text-sm mt-1">{errors.lastName}</p>}
          </div>
        </div>
        
        <div>
          <label htmlFor="email" className="block text-gray-700 mb-2">
            Email Address *
          </label>
          <input
            type="email"
            id="email"
            name="email"
            value={formData.email || ''}
            onChange={handleChange}
            className={`w-full p-3 border ${errors.email ? 'border-red-500' : 'border-gray-300'} rounded-md focus:outline-none focus:ring-2 focus:ring-primary-blue`}
            disabled={isLoading}
          />
          {errors.email && <p className="text-red-500 text-sm mt-1">{errors.email}</p>}
        </div>
        
        <div>
          <label htmlFor="phone" className="block text-gray-700 mb-2">
            Phone Number *
          </label>
          <input
            type="tel"
            id="phone"
            name="phone"
            value={formData.phone || ''}
            onChange={handleChange}
            className={`w-full p-3 border ${errors.phone ? 'border-red-500' : 'border-gray-300'} rounded-md focus:outline-none focus:ring-2 focus:ring-primary-blue`}
            disabled={isLoading}
          />
          {errors.phone && <p className="text-red-500 text-sm mt-1">{errors.phone}</p>}
        </div>
        
        <div>
          <label htmlFor="idNumber" className="block text-gray-700 mb-2">
            ID Number *
          </label>
          <input
            type="text"
            id="idNumber"
            name="idNumber"
            value={formData.idNumber || ''}
            onChange={handleChange}
            className={`w-full p-3 border ${errors.idNumber ? 'border-red-500' : 'border-gray-300'} rounded-md focus:outline-none focus:ring-2 focus:ring-primary-blue`}
            disabled={isLoading}
          />
          {errors.idNumber && <p className="text-red-500 text-sm mt-1">{errors.idNumber}</p>}
        </div>
        
        <div>
          <label htmlFor="address" className="block text-gray-700 mb-2">
            Physical Address *
          </label>
          <textarea
            id="address"
            name="address"
            value={formData.address || ''}
            onChange={handleChange}
            rows={3}
            className={`w-full p-3 border ${errors.address ? 'border-red-500' : 'border-gray-300'} rounded-md focus:outline-none focus:ring-2 focus:ring-primary-blue`}
            disabled={isLoading}
          ></textarea>
          {errors.address && <p className="text-red-500 text-sm mt-1">{errors.address}</p>}
        </div>
        
        <div className="flex justify-end">
          <button
            type="submit"
            className="bg-gradient-to-r from-primary-blue to-primary-teal text-white font-bold py-3 px-6 rounded-md hover:opacity-90 transition-opacity flex items-center"
            disabled={isLoading}
          >
            {isLoading ? (
              <>
                <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Processing...
              </>
            ) : 'Next'}
          </button>
        </div>
      </form>
    </div>
  );
};

// Driver & Vehicle Details Form (Step 2)
const DriverVehicleForm = ({ formData, setFormData, onNext, onPrevious }) => {
  const [errors, setErrors] = useState({});
  const [isLoading, setIsLoading] = useState(false);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const validateForm = () => {
    const newErrors = {};
    if (!formData.licenseNumber?.trim()) newErrors.licenseNumber = 'License number is required';
    if (!formData.licenseExpiry?.trim()) newErrors.licenseExpiry = 'License expiry date is required';
    if (!formData.operatingLocation?.trim()) newErrors.operatingLocation = 'Operating location is required';
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setIsLoading(true);
    
    if (validateForm()) {
      setTimeout(() => {
        setIsLoading(false);
        onNext();
      }, 500);
    } else {
      setIsLoading(false);
    }
  };

  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Driver & Vehicle Details</h2>
      <p className="text-gray-600 mb-6">Driver's license and vehicle preferences</p>
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="licenseNumber" className="block text-gray-700 mb-2">
            Driver's License Number *
          </label>
          <input
            type="text"
            id="licenseNumber"
            name="licenseNumber"
            value={formData.licenseNumber || ''}
            onChange={handleChange}
            className={`w-full p-3 border ${errors.licenseNumber ? 'border-red-500' : 'border-gray-300'} rounded-md focus:outline-none focus:ring-2 focus:ring-primary-blue`}
            disabled={isLoading}
          />
          {errors.licenseNumber && <p className="text-red-500 text-sm mt-1">{errors.licenseNumber}</p>}
        </div>
        
        <div>
          <label htmlFor="licenseExpiry" className="block text-gray-700 mb-2">
            License Expiry Date *
          </label>
          <input
            type="date"
            id="licenseExpiry"
            name="licenseExpiry"
            value={formData.licenseExpiry || ''}
            onChange={handleChange}
            className={`w-full p-3 border ${errors.licenseExpiry ? 'border-red-500' : 'border-gray-300'} rounded-md focus:outline-none focus:ring-2 focus:ring-primary-blue`}
            disabled={isLoading}
          />
          {errors.licenseExpiry && <p className="text-red-500 text-sm mt-1">{errors.licenseExpiry}</p>}
        </div>
        
        <div>
          <label htmlFor="operatingLocation" className="block text-gray-700 mb-2">
            Preferred Operating Location *
          </label>
          <select
            id="operatingLocation"
            name="operatingLocation"
            value={formData.operatingLocation || ''}
            onChange={handleChange}
            className={`w-full p-3 border ${errors.operatingLocation ? 'border-red-500' : 'border-gray-300'} rounded-md focus:outline-none focus:ring-2 focus:ring-primary-blue`}
            disabled={isLoading}
          >
            <option value="">Select your preferred location</option>
            <option value="Pretoria">Pretoria</option>
            <option value="Cape Town">Cape Town</option>
            <option value="Both Locations">Both Locations</option>
          </select>
          {errors.operatingLocation && <p className="text-red-500 text-sm mt-1">{errors.operatingLocation}</p>}
        </div>
        
        <div>
          <label htmlFor="vehicleCategory" className="block text-gray-700 mb-2">
            Vehicle Category Preference
          </label>
          <select
            id="vehicleCategory"
            name="vehicleCategory"
            value={formData.vehicleCategory || ''}
            onChange={handleChange}
            className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-blue"
            disabled={isLoading}
          >
            <option value="">Select vehicle category</option>
            <option value="Economy">Economy</option>
            <option value="Compact">Compact</option>
            <option value="SUV">SUV</option>
            <option value="Luxury">Luxury</option>
          </select>
        </div>
        
        <div>
          <label htmlFor="drivingExperience" className="block text-gray-700 mb-2">
            Driving Experience (years)
          </label>
          <input
            type="number"
            id="drivingExperience"
            name="drivingExperience"
            placeholder="Years of professional driving experience"
            value={formData.drivingExperience || ''}
            onChange={handleChange}
            className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-blue"
            disabled={isLoading}
          />
        </div>
        
        <div className="flex justify-between">
          <button
            type="button"
            onClick={onPrevious}
            className="bg-gray-300 text-gray-700 font-bold py-3 px-6 rounded-md hover:bg-gray-400 transition-colors"
            disabled={isLoading}
          >
            Previous
          </button>
          <button
            type="submit"
            className="bg-gradient-to-r from-primary-blue to-primary-teal text-white font-bold py-3 px-6 rounded-md hover:opacity-90 transition-opacity flex items-center"
            disabled={isLoading}
          >
            {isLoading ? (
              <>
                <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Processing...
              </>
            ) : 'Next'}
          </button>
        </div>
      </form>
    </div>
  );
};

// Banking & Preferences Form (Step 3)
const BankingPreferencesForm = ({ formData, setFormData, onSubmit, onPrevious }) => {
  const [errors, setErrors] = useState({});
  const [termsAccepted, setTermsAccepted] = useState(false);
  const [isLoading, setIsLoading] = useState(false);
  const [apiError, setApiError] = useState(null);

  const handleChange = (e) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const validateForm = () => {
    const newErrors = {};
    if (!formData.bankName?.trim()) newErrors.bankName = 'Bank name is required';
    if (!formData.accountNumber?.trim()) newErrors.accountNumber = 'Account number is required';
    if (!termsAccepted) newErrors.terms = 'You must agree to the terms and conditions';
    
    setErrors(newErrors);
    return Object.keys(newErrors).length === 0;
  };

  const handleSubmit = async (e) => {
    e.preventDefault();
    setIsLoading(true);
    setApiError(null);
    
    if (validateForm()) {
      try {
        // Prepare data for API
        const driverData = {
          ...formData,
          termsAccepted
        };
        
        // Call API to register driver
        await driverService.registerDriver(driverData);
        onSubmit();
      } catch (error) {
        console.error('Error submitting driver application:', error);
        setApiError(typeof error === 'string' ? error : 'Failed to submit application. Please try again.');
      } finally {
        setIsLoading(false);
      }
    } else {
      setIsLoading(false);
    }
  };

  return (
    <div>
      <h2 className="text-2xl font-bold mb-4">Banking & Preferences</h2>
      <p className="text-gray-600 mb-6">Banking details and final preferences</p>
      
      {apiError && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-6">
          <p>{apiError}</p>
        </div>
      )}
      
      <form onSubmit={handleSubmit} className="space-y-4">
        <div>
          <label htmlFor="bankName" className="block text-gray-700 mb-2">
            Bank Name *
          </label>
          <input
            type="text"
            id="bankName"
            name="bankName"
            value={formData.bankName || ''}
            onChange={handleChange}
            className={`w-full p-3 border ${errors.bankName ? 'border-red-500' : 'border-gray-300'} rounded-md focus:outline-none focus:ring-2 focus:ring-primary-blue`}
            disabled={isLoading}
          />
          {errors.bankName && <p className="text-red-500 text-sm mt-1">{errors.bankName}</p>}
        </div>
        
        <div>
          <label htmlFor="accountNumber" className="block text-gray-700 mb-2">
            Account Number *
          </label>
          <input
            type="text"
            id="accountNumber"
            name="accountNumber"
            value={formData.accountNumber || ''}
            onChange={handleChange}
            className={`w-full p-3 border ${errors.accountNumber ? 'border-red-500' : 'border-gray-300'} rounded-md focus:outline-none focus:ring-2 focus:ring-primary-blue`}
            disabled={isLoading}
          />
          {errors.accountNumber && <p className="text-red-500 text-sm mt-1">{errors.accountNumber}</p>}
        </div>
        
        <div className="flex items-start mt-4">
          <input
            type="checkbox"
            id="terms"
            checked={termsAccepted}
            onChange={() => setTermsAccepted(!termsAccepted)}
            className="mt-1 mr-2"
            disabled={isLoading}
          />
          <label htmlFor="terms" className={`text-sm ${errors.terms ? 'text-red-500' : 'text-gray-700'}`}>
            I agree to the terms and conditions and contractor agreement
          </label>
        </div>
        {errors.terms && <p className="text-red-500 text-sm">{errors.terms}</p>}
        
        <div className="bg-blue-50 p-4 rounded-md mt-6">
          <h3 className="font-bold text-lg mb-2">Next Steps:</h3>
          <ul className="list-disc pl-5 space-y-1 text-gray-700">
            <li>Background check and document verification</li>
            <li>Vehicle assignment based on availability</li>
            <li>Driver orientation and training</li>
            <li>Platform onboarding</li>
          </ul>
        </div>
        
        <div className="flex justify-between">
          <button
            type="button"
            onClick={onPrevious}
            className="bg-gray-300 text-gray-700 font-bold py-3 px-6 rounded-md hover:bg-gray-400 transition-colors"
            disabled={isLoading}
          >
            Previous
          </button>
          <button
            type="submit"
            className="bg-gradient-to-r from-primary-blue to-primary-teal text-white font-bold py-3 px-6 rounded-md hover:opacity-90 transition-opacity flex items-center"
            disabled={isLoading}
          >
            {isLoading ? (
              <>
                <svg className="animate-spin -ml-1 mr-3 h-5 w-5 text-white" xmlns="http://www.w3.org/2000/svg" fill="none" viewBox="0 0 24 24">
                  <circle className="opacity-25" cx="12" cy="12" r="10" stroke="currentColor" strokeWidth="4"></circle>
                  <path className="opacity-75" fill="currentColor" d="M4 12a8 8 0 018-8V0C5.373 0 0 5.373 0 12h4zm2 5.291A7.962 7.962 0 014 12H0c0 3.042 1.135 5.824 3 7.938l3-2.647z"></path>
                </svg>
                Submitting...
              </>
            ) : 'Submit Application'}
          </button>
        </div>
      </form>
    </div>
  );
};

// Main Driver Signup Component
const DriverSignup = () => {
  const [currentStep, setCurrentStep] = useState(1);
  const [formData, setFormData] = useState({});
  const [submitSuccess, setSubmitSuccess] = useState(false);
  const navigate = useNavigate();

  const handleNext = () => {
    setCurrentStep(prev => prev + 1);
    window.scrollTo(0, 0);
  };

  const handlePrevious = () => {
    setCurrentStep(prev => prev - 1);
    window.scrollTo(0, 0);
  };

  const handleSubmit = () => {
    setSubmitSuccess(true);
    // Redirect to success page or home page after successful submission
    setTimeout(() => {
      navigate('/');
    }, 3000);
  };

  const renderStepContent = () => {
    switch (currentStep) {
      case 1:
        return (
          <PersonalInfoForm 
            formData={formData} 
            setFormData={setFormData} 
            onNext={handleNext} 
          />
        );
      case 2:
        return (
          <DriverVehicleForm 
            formData={formData} 
            setFormData={setFormData} 
            onNext={handleNext} 
            onPrevious={handlePrevious} 
          />
        );
      case 3:
        return (
          <BankingPreferencesForm 
            formData={formData} 
            setFormData={setFormData} 
            onSubmit={handleSubmit} 
            onPrevious={handlePrevious} 
          />
        );
      default:
        return null;
    }
  };

  return (
    <div className="py-16 md:py-24">
      <div className="container mx-auto px-4">
        <h1 className="text-4xl font-bold text-center text-primary-blue mb-4">Join Vhamba Logistics</h1>
        <p className="text-center text-gray-600 mb-12">
          Become an independent contractor and start earning with our premium vehicle fleet
        </p>
        
        <StepIndicator currentStep={currentStep} totalSteps={3} />
        
        {submitSuccess ? (
          <div className="bg-green-100 border border-green-400 text-green-700 px-6 py-4 rounded-lg text-center">
            <h2 className="text-2xl font-bold mb-2">Application Submitted Successfully!</h2>
            <p>Thank you for your application. We will contact you shortly to proceed with the next steps.</p>
            <p className="mt-4">Redirecting to home page...</p>
          </div>
        ) : (
          <div className="bg-white rounded-lg shadow-md p-6 md:p-8 max-w-3xl mx-auto">
            {renderStepContent()}
          </div>
        )}
      </div>
    </div>
  );
};

export default DriverSignup;
