import React, { useState, useEffect } from 'react';
import { vehicleAPI } from '../services/api';
import VehicleCard from '../components/vehicles/VehicleCard';

// Updated to use TypeScript interfaces
interface Vehicle {
  _id: string;
  name: string;
  price: string;
  image: string;
  vehicleClass: 'economy' | 'premium' | 'suv';
  fuelType: string;
  seats: number;
  transmission: string;
  rating: number;
}

const FleetPage: React.FC = () => {
  const [activeTab, setActiveTab] = useState<'economy' | 'premium' | 'suv'>('economy');
  const [vehicles, setVehicles] = useState<Vehicle[]>([]);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  // Fetch vehicles based on active tab
  useEffect(() => {
    const fetchVehicles = async () => {
      try {
        setLoading(true);
        const response = await vehicleAPI.getVehiclesByClass(activeTab);
        setVehicles(response.data);
        setError(null);
      } catch (err) {
        console.error('Failed to fetch vehicles:', err);
        setError('Failed to load vehicles. Please try again later.');
        // Fallback to placeholder data if API fails
        setVehicles(getPlaceholderVehicles(activeTab));
      } finally {
        setLoading(false);
      }
    };

    fetchVehicles();
  }, [activeTab]);

  // Placeholder data for fallback
  const getPlaceholderVehicles = (vehicleClass: string): Vehicle[] => {
    const placeholderImages = {
      economy1: 'https://images.unsplash.com/photo-1541899481282-d53bffe3c35d?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
      economy2: 'https://images.unsplash.com/photo-1549317661-bd32c8ce0db2?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
      premium1: 'https://images.unsplash.com/photo-1549399542-7e3f8b79c341?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
      premium2: 'https://images.unsplash.com/photo-1553440569-bcc63803a83d?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
      suv1: 'https://images.unsplash.com/photo-1519641471654-76ce0107ad1b?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
      suv2: 'https://images.unsplash.com/photo-1533473359331-0135ef1b58bf?ixlib=rb-1.2.1&auto=format&fit=crop&w=1350&q=80',
    };

    switch (vehicleClass) {
      case 'economy':
        return [
          {
            _id: '1',
            name: 'Toyota Corolla Quest',
            price: 'R350/day',
            image: placeholderImages.economy1,
            vehicleClass: 'economy',
            fuelType: 'Petrol',
            seats: 5,
            transmission: 'Manual',
            rating: 4.5,
          },
          {
            _id: '2',
            name: 'Nissan Almera',
            price: 'R320/day',
            image: placeholderImages.economy2,
            vehicleClass: 'economy',
            fuelType: 'Petrol',
            seats: 5,
            transmission: 'CVT',
            rating: 4.3,
          },
        ];
      case 'premium':
        return [
          {
            _id: '3',
            name: 'Toyota Camry',
            price: 'R550/day',
            image: placeholderImages.premium1,
            vehicleClass: 'premium',
            fuelType: 'Petrol',
            seats: 5,
            transmission: 'Automatic',
            rating: 4.7,
          },
          {
            _id: '4',
            name: 'BMW 3 Series',
            price: 'R750/day',
            image: placeholderImages.premium2,
            vehicleClass: 'premium',
            fuelType: 'Petrol',
            seats: 5,
            transmission: 'Automatic',
            rating: 4.8,
          },
        ];
      case 'suv':
        return [
          {
            _id: '5',
            name: 'Toyota Fortuner',
            price: 'R650/day',
            image: placeholderImages.suv1,
            vehicleClass: 'suv',
            fuelType: 'Diesel',
            seats: 7,
            transmission: 'Automatic',
            rating: 4.6,
          },
          {
            _id: '6',
            name: 'Ford Everest',
            price: 'R620/day',
            image: placeholderImages.suv2,
            vehicleClass: 'suv',
            fuelType: 'Diesel',
            seats: 7,
            transmission: 'Automatic',
            rating: 4.5,
          },
        ];
      default:
        return [];
    }
  };

  // Handle quote request
  const handleQuoteRequest = async (vehicleId: string) => {
    // This will be implemented to connect to the backend
    console.log(`Quote requested for vehicle ID: ${vehicleId}`);
    // Redirect to quote form or open modal
  };

  return (
    <div>
      <section className="py-16 md:py-24">
        <div className="container mx-auto px-4">
          <h2 className="section-title">
            <span>Our</span> <span>Fleet</span>
          </h2>
          <p className="section-description">
            Choose from our diverse range of well-maintained vehicles, each equipped for optimal performance in the e-hailing industry.
          </p>
          
          {/* Vehicle Class Tabs */}
          <div className="flex justify-center mb-12">
            <div className="inline-flex rounded-md border border-gray-200 overflow-hidden">
              <button
                className={`px-6 py-3 font-medium ${activeTab === 'economy' ? 'bg-primary-blue text-white' : 'bg-white text-gray-700 hover:bg-gray-50'}`}
                onClick={() => setActiveTab('economy')}
              >
                Economy Class
              </button>
              <button
                className={`px-6 py-3 font-medium ${activeTab === 'premium' ? 'bg-primary-blue text-white' : 'bg-white text-gray-700 hover:bg-gray-50'}`}
                onClick={() => setActiveTab('premium')}
              >
                Premium Class
              </button>
              <button
                className={`px-6 py-3 font-medium ${activeTab === 'suv' ? 'bg-primary-blue text-white' : 'bg-white text-gray-700 hover:bg-gray-50'}`}
                onClick={() => setActiveTab('suv')}
              >
                SUV Class
              </button>
            </div>
          </div>
          
          {/* Vehicle Class Description */}
          <div className="mb-12">
            {activeTab === 'economy' && (
              <div className="text-center">
                <h3 className="text-2xl font-bold mb-2">Economy Class</h3>
                <p className="text-gray-600">Perfect for new contractors starting their e-hailing journey</p>
              </div>
            )}
            {activeTab === 'premium' && (
              <div className="text-center">
                <h3 className="text-2xl font-bold mb-2">Premium Class</h3>
                <p className="text-gray-600">Enhanced comfort and style for experienced contractors</p>
              </div>
            )}
            {activeTab === 'suv' && (
              <div className="text-center">
                <h3 className="text-2xl font-bold mb-2">SUV Class</h3>
                <p className="text-gray-600">Spacious vehicles for family trips and group transport</p>
              </div>
            )}
          </div>
          
          {/* Loading and Error States */}
          {loading && (
            <div className="text-center py-12">
              <div className="inline-block animate-spin rounded-full h-8 w-8 border-t-2 border-b-2 border-primary-blue"></div>
              <p className="mt-2 text-gray-600">Loading vehicles...</p>
            </div>
          )}
          
          {error && !loading && (
            <div className="text-center py-12">
              <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded relative" role="alert">
                <strong className="font-bold">Error: </strong>
                <span className="block sm:inline">{error}</span>
              </div>
            </div>
          )}
          
          {/* Vehicle Cards */}
          {!loading && !error && (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-8">
              {vehicles.map((vehicle) => (
                <VehicleCard
                  key={vehicle._id}
                  name={vehicle.name}
                  price={vehicle.price}
                  image={vehicle.image}
                  fuelType={vehicle.fuelType}
                  seats={vehicle.seats}
                  transmission={vehicle.transmission}
                  rating={vehicle.rating}
                />
              ))}
            </div>
          )}
        </div>
      </section>
    </div>
  );
};

export default FleetPage;
