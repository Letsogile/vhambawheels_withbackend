import React, { useState } from 'react';
import { leaseInquiryAPI } from '../services/api';

interface LeaseInquiryFormProps {}

const LeaseInquiryForm: React.FC<LeaseInquiryFormProps> = () => {
  const [formData, setFormData] = useState({
    location: '',
    startDate: '',
    leasePeriod: ''
  });
  const [loading, setLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);
  const [success, setSuccess] = useState(false);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { name, value } = e.target;
    setFormData(prev => ({
      ...prev,
      [name]: value
    }));
  };

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    try {
      setLoading(true);
      setError(null);
      setSuccess(false);
      
      // Call the API to submit the inquiry
      await leaseInquiryAPI.submitInquiry(formData);
      
      // Reset form and show success message
      setFormData({
        location: '',
        startDate: '',
        leasePeriod: ''
      });
      setSuccess(true);
    } catch (err: any) {
      console.error('Failed to submit lease inquiry:', err);
      setError(err.response?.data?.message || 'Failed to submit inquiry. Please try again.');
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="bg-white rounded-lg shadow-lg p-6">
      <h2 className="text-2xl font-bold mb-4">Quick Lease Inquiry</h2>
      
      {success && (
        <div className="bg-green-100 border border-green-400 text-green-700 px-4 py-3 rounded mb-4" role="alert">
          <p>Your inquiry has been submitted successfully! We'll contact you shortly.</p>
        </div>
      )}
      
      {error && (
        <div className="bg-red-100 border border-red-400 text-red-700 px-4 py-3 rounded mb-4" role="alert">
          <p>{error}</p>
        </div>
      )}
      
      <form onSubmit={handleSubmit}>
        <div className="mb-4">
          <label htmlFor="location" className="block text-gray-700 mb-2">
            Preferred Location
          </label>
          <select
            id="location"
            name="location"
            className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-blue"
            value={formData.location}
            onChange={handleChange}
            required
            disabled={loading}
          >
            <option value="">Select Location</option>
            <option value="Pretoria Office">Pretoria Office</option>
            <option value="Cape Town Office">Cape Town Office</option>
          </select>
        </div>
        
        <div className="mb-4">
          <label htmlFor="startDate" className="block text-gray-700 mb-2">
            Start Date
          </label>
          <input
            type="date"
            id="startDate"
            name="startDate"
            className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-blue"
            value={formData.startDate}
            onChange={handleChange}
            required
            disabled={loading}
          />
        </div>
        
        <div className="mb-6">
          <label htmlFor="leasePeriod" className="block text-gray-700 mb-2">
            Lease Period
          </label>
          <select
            id="leasePeriod"
            name="leasePeriod"
            className="w-full p-3 border border-gray-300 rounded-md focus:outline-none focus:ring-2 focus:ring-primary-blue"
            value={formData.leasePeriod}
            onChange={handleChange}
            required
            disabled={loading}
          >
            <option value="">Select Period</option>
            <option value="1 Month">1 Month</option>
            <option value="3 Months">3 Months</option>
            <option value="6 Months">6 Months</option>
            <option value="12 Months">12 Months</option>
          </select>
        </div>
        
        <button 
          type="submit" 
          className={`w-full bg-gradient-to-r from-primary-blue to-primary-teal text-white font-bold py-3 px-4 rounded-md transition-opacity ${loading ? 'opacity-70 cursor-not-allowed' : 'hover:opacity-90'}`}
          disabled={loading}
        >
          {loading ? 'Submitting...' : 'Get Lease Quote'}
        </button>
      </form>
      
      <p className="text-center text-gray-500 mt-4">
        Free consultation • No hidden fees
      </p>
    </div>
  );
};

export default LeaseInquiryForm;
