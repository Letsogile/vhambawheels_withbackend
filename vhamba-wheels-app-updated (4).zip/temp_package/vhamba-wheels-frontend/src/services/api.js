import axios from 'axios';

// Create axios instance with base URL
const api = axios.create({
  baseURL: process.env.REACT_APP_API_URL || 'http://localhost:5000/api',
  headers: {
    'Content-Type': 'application/json'
  }
});

// Add auth token to requests if available
api.interceptors.request.use(
  (config) => {
    const token = localStorage.getItem('token');
    if (token) {
      config.headers.Authorization = `Bearer ${token}`;
    }
    return config;
  },
  (error) => Promise.reject(error)
);

// Driver API services
export const driverService = {
  // Register new driver (onboarding)
  registerDriver: async (driverData) => {
    try {
      const response = await api.post('/drivers/register', driverData);
      return response.data;
    } catch (error) {
      throw error.response?.data?.error || 'Failed to register driver';
    }
  },
  
  // Get current driver profile
  getProfile: async () => {
    try {
      const response = await api.get('/drivers/me');
      return response.data;
    } catch (error) {
      throw error.response?.data?.error || 'Failed to get profile';
    }
  },
  
  // Update driver details
  updateDetails: async (driverData) => {
    try {
      const response = await api.put('/drivers/updatedetails', driverData);
      return response.data;
    } catch (error) {
      throw error.response?.data?.error || 'Failed to update details';
    }
  },
  
  // Update password
  updatePassword: async (passwordData) => {
    try {
      const response = await api.put('/drivers/updatepassword', passwordData);
      return response.data;
    } catch (error) {
      throw error.response?.data?.error || 'Failed to update password';
    }
  }
};

// Payment API services
export const paymentService = {
  // Process a payment
  processPayment: async (paymentData) => {
    try {
      const response = await api.post('/payments', paymentData);
      return response.data;
    } catch (error) {
      throw error.response?.data?.error || 'Failed to process payment';
    }
  },
  
  // Get driver's payment history
  getMyPayments: async () => {
    try {
      const response = await api.get('/payments/me');
      return response.data;
    } catch (error) {
      throw error.response?.data?.error || 'Failed to get payment history';
    }
  }
};

// Authentication services
export const authService = {
  // Login user
  login: async (email, password) => {
    try {
      const response = await api.post('/auth/login', { email, password });
      if (response.data.token) {
        localStorage.setItem('token', response.data.token);
      }
      return response.data;
    } catch (error) {
      throw error.response?.data?.error || 'Login failed';
    }
  },
  
  // Logout user
  logout: () => {
    localStorage.removeItem('token');
  },
  
  // Check if user is logged in
  isLoggedIn: () => {
    return !!localStorage.getItem('token');
  }
};

// Vehicle services
export const vehicleService = {
  // Get all vehicles
  getVehicles: async () => {
    try {
      const response = await api.get('/vehicles');
      return response.data;
    } catch (error) {
      throw error.response?.data?.error || 'Failed to get vehicles';
    }
  },
  
  // Get vehicles by class
  getVehiclesByClass: async (vehicleClass) => {
    try {
      const response = await api.get(`/vehicles/class/${vehicleClass}`);
      return response.data;
    } catch (error) {
      throw error.response?.data?.error || 'Failed to get vehicles by class';
    }
  },
  
  // Get vehicle by ID
  getVehicleById: async (id) => {
    try {
      const response = await api.get(`/vehicles/${id}`);
      return response.data;
    } catch (error) {
      throw error.response?.data?.error || 'Failed to get vehicle';
    }
  }
};

// Location services
export const locationService = {
  // Get all locations
  getLocations: async () => {
    try {
      const response = await api.get('/locations');
      return response.data;
    } catch (error) {
      throw error.response?.data?.error || 'Failed to get locations';
    }
  }
};

export default {
  driverService,
  paymentService,
  authService,
  vehicleService,
  locationService
};
