/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./src/**/*.{js,jsx,ts,tsx}",
  ],
  theme: {
    extend: {
      colors: {
        'primary-blue': '#2563eb',
        'primary-teal': '#10b981',
        'dark-blue': '#1e293b',
        'light-blue': '#f1f5f9',
        'gray': '#64748b',
      },
      fontFamily: {
        sans: ['Inter', 'sans-serif'],
      },
      backgroundImage: {
        'gradient-primary': 'linear-gradient(to right, #2563eb, #10b981)',
      },
    },
  },
  plugins: [],
}
