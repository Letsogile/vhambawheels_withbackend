const asyncHandler = require('../middleware/async');
const ErrorResponse = require('../utils/errorResponse');
const LeaseInquiry = require('../models/LeaseInquiry');

// @desc    Get all lease inquiries
// @route   GET /api/lease-inquiries
// @access  Private
exports.getLeaseInquiries = asyncHandler(async (req, res, next) => {
  let query;
  
  // If user is not admin, show only their inquiries
  if (req.user.role !== 'admin') {
    query = LeaseInquiry.find({ user: req.user.id });
  } else {
    query = LeaseInquiry.find().populate({
      path: 'user',
      select: 'name email phone'
    });
  }
  
  // Add location data
  query = query.populate({
    path: 'location',
    select: 'name city'
  });
  
  const leaseInquiries = await query;
  
  res.status(200).json({
    success: true,
    count: leaseInquiries.length,
    data: leaseInquiries
  });
});

// @desc    Get single lease inquiry
// @route   GET /api/lease-inquiries/:id
// @access  Private
exports.getLeaseInquiry = asyncHandler(async (req, res, next) => {
  const leaseInquiry = await LeaseInquiry.findById(req.params.id)
    .populate({
      path: 'user',
      select: 'name email phone'
    })
    .populate({
      path: 'location',
      select: 'name city address'
    });
    
  if (!leaseInquiry) {
    return next(
      new ErrorResponse(`Lease inquiry not found with id of ${req.params.id}`, 404)
    );
  }
  
  // Make sure user is inquiry owner or admin
  if (leaseInquiry.user && leaseInquiry.user._id.toString() !== req.user.id && req.user.role !== 'admin') {
    return next(
      new ErrorResponse(`User ${req.user.id} is not authorized to access this inquiry`, 401)
    );
  }
  
  res.status(200).json({
    success: true,
    data: leaseInquiry
  });
});

// @desc    Create new lease inquiry
// @route   POST /api/lease-inquiries
// @access  Public/Private
exports.createLeaseInquiry = asyncHandler(async (req, res, next) => {
  // If user is logged in, add user to body
  if (req.user) {
    req.body.user = req.user.id;
  }
  
  const leaseInquiry = await LeaseInquiry.create(req.body);
  
  res.status(201).json({
    success: true,
    data: leaseInquiry
  });
});

// @desc    Update lease inquiry
// @route   PUT /api/lease-inquiries/:id
// @access  Private/Admin
exports.updateLeaseInquiry = asyncHandler(async (req, res, next) => {
  let leaseInquiry = await LeaseInquiry.findById(req.params.id);
  
  if (!leaseInquiry) {
    return next(
      new ErrorResponse(`Lease inquiry not found with id of ${req.params.id}`, 404)
    );
  }
  
  // Make sure user is inquiry owner or admin
  if (leaseInquiry.user && leaseInquiry.user.toString() !== req.user.id && req.user.role !== 'admin') {
    return next(
      new ErrorResponse(`User ${req.user.id} is not authorized to update this inquiry`, 401)
    );
  }
  
  leaseInquiry = await LeaseInquiry.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true
  });
  
  res.status(200).json({
    success: true,
    data: leaseInquiry
  });
});

// @desc    Delete lease inquiry
// @route   DELETE /api/lease-inquiries/:id
// @access  Private/Admin
exports.deleteLeaseInquiry = asyncHandler(async (req, res, next) => {
  const leaseInquiry = await LeaseInquiry.findById(req.params.id);
  
  if (!leaseInquiry) {
    return next(
      new ErrorResponse(`Lease inquiry not found with id of ${req.params.id}`, 404)
    );
  }
  
  // Make sure user is inquiry owner or admin
  if (leaseInquiry.user && leaseInquiry.user.toString() !== req.user.id && req.user.role !== 'admin') {
    return next(
      new ErrorResponse(`User ${req.user.id} is not authorized to delete this inquiry`, 401)
    );
  }
  
  await leaseInquiry.deleteOne();
  
  res.status(200).json({
    success: true,
    data: {}
  });
});
