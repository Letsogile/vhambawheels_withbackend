const asyncHandler = require('../middleware/async');
const ErrorResponse = require('../utils/errorResponse');
const ContactMessage = require('../models/ContactMessage');

// @desc    Get all contact messages
// @route   GET /api/contact
// @access  Private/Admin
exports.getContactMessages = asyncHandler(async (req, res, next) => {
  const contactMessages = await ContactMessage.find().populate({
    path: 'location',
    select: 'name city'
  });
  
  res.status(200).json({
    success: true,
    count: contactMessages.length,
    data: contactMessages
  });
});

// @desc    Get single contact message
// @route   GET /api/contact/:id
// @access  Private/Admin
exports.getContactMessage = asyncHandler(async (req, res, next) => {
  const contactMessage = await ContactMessage.findById(req.params.id).populate({
    path: 'location',
    select: 'name city address'
  });
  
  if (!contactMessage) {
    return next(
      new ErrorResponse(`Contact message not found with id of ${req.params.id}`, 404)
    );
  }
  
  res.status(200).json({
    success: true,
    data: contactMessage
  });
});

// @desc    Create new contact message
// @route   POST /api/contact
// @access  Public
exports.createContactMessage = asyncHandler(async (req, res, next) => {
  const contactMessage = await ContactMessage.create(req.body);
  
  res.status(201).json({
    success: true,
    data: contactMessage
  });
});

// @desc    Update contact message status
// @route   PUT /api/contact/:id
// @access  Private/Admin
exports.updateContactMessage = asyncHandler(async (req, res, next) => {
  let contactMessage = await ContactMessage.findById(req.params.id);
  
  if (!contactMessage) {
    return next(
      new ErrorResponse(`Contact message not found with id of ${req.params.id}`, 404)
    );
  }
  
  contactMessage = await ContactMessage.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true
  });
  
  res.status(200).json({
    success: true,
    data: contactMessage
  });
});

// @desc    Delete contact message
// @route   DELETE /api/contact/:id
// @access  Private/Admin
exports.deleteContactMessage = asyncHandler(async (req, res, next) => {
  const contactMessage = await ContactMessage.findById(req.params.id);
  
  if (!contactMessage) {
    return next(
      new ErrorResponse(`Contact message not found with id of ${req.params.id}`, 404)
    );
  }
  
  await contactMessage.deleteOne();
  
  res.status(200).json({
    success: true,
    data: {}
  });
});
