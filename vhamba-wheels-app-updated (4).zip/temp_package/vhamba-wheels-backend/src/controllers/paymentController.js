const asyncHandler = require('../middleware/async');
const ErrorResponse = require('../utils/errorResponse');
const Payment = require('../models/Payment');
const Driver = require('../models/Driver');
const Vehicle = require('../models/Vehicle');

// @desc    Process payment
// @route   POST /api/v1/payments
// @access  Public
exports.processPayment = asyncHandler(async (req, res, next) => {
  const {
    paymentType,
    vehicleId,
    amount,
    cardholderName,
    cardNumber,
    expiryDate,
    cvv
  } = req.body;

  // Validate amount
  if (!amount || amount <= 0) {
    return next(new ErrorResponse('Please enter a valid amount', 400));
  }

  // Validate card details (basic validation)
  if (!cardholderName || !cardNumber || !expiryDate || !cvv) {
    return next(new ErrorResponse('Please provide all card details', 400));
  }

  // Extract last 4 digits of card number for reference
  const lastFourDigits = cardNumber.replace(/\s/g, '').slice(-4);

  // Generate a transaction ID
  const transactionId = 'TXN' + Date.now() + Math.floor(Math.random() * 1000);

  // Find vehicle if vehicleId is provided
  let vehicle = null;
  if (vehicleId) {
    vehicle = await Vehicle.findById(vehicleId);
    if (!vehicle) {
      return next(new ErrorResponse(`Vehicle not found with id of ${vehicleId}`, 404));
    }
  }

  // Create payment record
  const payment = await Payment.create({
    paymentType,
    vehicleId,
    amount: parseFloat(amount),
    processingFee: 5.00, // Fixed processing fee
    cardholderName,
    lastFourDigits,
    paymentStatus: 'completed', // In a real app, this would be set after payment gateway confirmation
    transactionId,
    vehicle: vehicle ? vehicle._id : null,
    driver: req.driver ? req.driver.id : null
  });

  // In a real application, you would integrate with a payment gateway here
  // For this demo, we'll simulate a successful payment

  res.status(201).json({
    success: true,
    data: {
      id: payment._id,
      transactionId: payment.transactionId,
      amount: payment.amount,
      processingFee: payment.processingFee,
      totalAmount: payment.totalAmount,
      paymentStatus: payment.paymentStatus,
      paymentType: payment.paymentType,
      createdAt: payment.createdAt
    },
    message: 'Payment processed successfully'
  });
});

// @desc    Get all payments
// @route   GET /api/v1/payments
// @access  Private/Admin
exports.getPayments = asyncHandler(async (req, res, next) => {
  res.status(200).json(res.advancedResults);
});

// @desc    Get single payment
// @route   GET /api/v1/payments/:id
// @access  Private/Admin
exports.getPayment = asyncHandler(async (req, res, next) => {
  const payment = await Payment.findById(req.params.id)
    .populate({
      path: 'driver',
      select: 'firstName lastName email'
    })
    .populate({
      path: 'vehicle',
      select: 'make model year licensePlate'
    });

  if (!payment) {
    return next(new ErrorResponse(`Payment not found with id of ${req.params.id}`, 404));
  }

  res.status(200).json({
    success: true,
    data: payment
  });
});

// @desc    Get payments for a driver
// @route   GET /api/v1/drivers/:driverId/payments
// @access  Private/Admin
exports.getDriverPayments = asyncHandler(async (req, res, next) => {
  const driver = await Driver.findById(req.params.driverId);

  if (!driver) {
    return next(new ErrorResponse(`Driver not found with id of ${req.params.driverId}`, 404));
  }

  const payments = await Payment.find({ driver: req.params.driverId })
    .populate({
      path: 'vehicle',
      select: 'make model year licensePlate'
    });

  res.status(200).json({
    success: true,
    count: payments.length,
    data: payments
  });
});

// @desc    Get payments for a vehicle
// @route   GET /api/v1/vehicles/:vehicleId/payments
// @access  Private/Admin
exports.getVehiclePayments = asyncHandler(async (req, res, next) => {
  const vehicle = await Vehicle.findById(req.params.vehicleId);

  if (!vehicle) {
    return next(new ErrorResponse(`Vehicle not found with id of ${req.params.vehicleId}`, 404));
  }

  const payments = await Payment.find({ vehicle: req.params.vehicleId })
    .populate({
      path: 'driver',
      select: 'firstName lastName email'
    });

  res.status(200).json({
    success: true,
    count: payments.length,
    data: payments
  });
});

// @desc    Update payment status
// @route   PUT /api/v1/payments/:id/status
// @access  Private/Admin
exports.updatePaymentStatus = asyncHandler(async (req, res, next) => {
  const { paymentStatus } = req.body;

  if (!['pending', 'completed', 'failed', 'refunded'].includes(paymentStatus)) {
    return next(new ErrorResponse('Invalid payment status value', 400));
  }

  let payment = await Payment.findById(req.params.id);

  if (!payment) {
    return next(new ErrorResponse(`Payment not found with id of ${req.params.id}`, 404));
  }

  payment = await Payment.findByIdAndUpdate(
    req.params.id,
    { paymentStatus },
    {
      new: true,
      runValidators: true
    }
  );

  res.status(200).json({
    success: true,
    data: payment
  });
});

// @desc    Get my payments (for logged in driver)
// @route   GET /api/v1/payments/me
// @access  Private
exports.getMyPayments = asyncHandler(async (req, res, next) => {
  const payments = await Payment.find({ driver: req.driver.id })
    .populate({
      path: 'vehicle',
      select: 'make model year licensePlate'
    });

  res.status(200).json({
    success: true,
    count: payments.length,
    data: payments
  });
});
