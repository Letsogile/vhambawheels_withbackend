const asyncHandler = require('../middleware/async');
const ErrorResponse = require('../utils/errorResponse');
const QuoteRequest = require('../models/QuoteRequest');

// @desc    Get all quote requests
// @route   GET /api/quote-requests
// @access  Private
exports.getQuoteRequests = asyncHandler(async (req, res, next) => {
  let query;
  
  // If user is not admin, show only their requests
  if (req.user.role !== 'admin') {
    query = QuoteRequest.find({ user: req.user.id });
  } else {
    query = QuoteRequest.find().populate({
      path: 'user',
      select: 'name email phone'
    });
  }
  
  // Add vehicle and location data
  query = query.populate({
    path: 'vehicle',
    select: 'name class dailyRate'
  }).populate({
    path: 'location',
    select: 'name city'
  });
  
  const quoteRequests = await query;
  
  res.status(200).json({
    success: true,
    count: quoteRequests.length,
    data: quoteRequests
  });
});

// @desc    Get single quote request
// @route   GET /api/quote-requests/:id
// @access  Private
exports.getQuoteRequest = asyncHandler(async (req, res, next) => {
  const quoteRequest = await QuoteRequest.findById(req.params.id)
    .populate({
      path: 'user',
      select: 'name email phone'
    })
    .populate({
      path: 'vehicle',
      select: 'name class dailyRate fuelType transmission seats imageUrl'
    })
    .populate({
      path: 'location',
      select: 'name city address'
    });
    
  if (!quoteRequest) {
    return next(
      new ErrorResponse(`Quote request not found with id of ${req.params.id}`, 404)
    );
  }
  
  // Make sure user is request owner or admin
  if (quoteRequest.user && quoteRequest.user._id.toString() !== req.user.id && req.user.role !== 'admin') {
    return next(
      new ErrorResponse(`User ${req.user.id} is not authorized to access this request`, 401)
    );
  }
  
  res.status(200).json({
    success: true,
    data: quoteRequest
  });
});

// @desc    Create new quote request
// @route   POST /api/quote-requests
// @access  Public/Private
exports.createQuoteRequest = asyncHandler(async (req, res, next) => {
  // If user is logged in, add user to body
  if (req.user) {
    req.body.user = req.user.id;
  }
  
  const quoteRequest = await QuoteRequest.create(req.body);
  
  res.status(201).json({
    success: true,
    data: quoteRequest
  });
});

// @desc    Update quote request
// @route   PUT /api/quote-requests/:id
// @access  Private/Admin
exports.updateQuoteRequest = asyncHandler(async (req, res, next) => {
  let quoteRequest = await QuoteRequest.findById(req.params.id);
  
  if (!quoteRequest) {
    return next(
      new ErrorResponse(`Quote request not found with id of ${req.params.id}`, 404)
    );
  }
  
  // Make sure user is request owner or admin
  if (quoteRequest.user && quoteRequest.user.toString() !== req.user.id && req.user.role !== 'admin') {
    return next(
      new ErrorResponse(`User ${req.user.id} is not authorized to update this request`, 401)
    );
  }
  
  quoteRequest = await QuoteRequest.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true
  });
  
  res.status(200).json({
    success: true,
    data: quoteRequest
  });
});

// @desc    Delete quote request
// @route   DELETE /api/quote-requests/:id
// @access  Private/Admin
exports.deleteQuoteRequest = asyncHandler(async (req, res, next) => {
  const quoteRequest = await QuoteRequest.findById(req.params.id);
  
  if (!quoteRequest) {
    return next(
      new ErrorResponse(`Quote request not found with id of ${req.params.id}`, 404)
    );
  }
  
  // Make sure user is request owner or admin
  if (quoteRequest.user && quoteRequest.user.toString() !== req.user.id && req.user.role !== 'admin') {
    return next(
      new ErrorResponse(`User ${req.user.id} is not authorized to delete this request`, 401)
    );
  }
  
  await quoteRequest.deleteOne();
  
  res.status(200).json({
    success: true,
    data: {}
  });
});
