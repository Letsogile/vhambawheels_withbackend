const asyncHandler = require('../middleware/async');
const ErrorResponse = require('../utils/errorResponse');
const Driver = require('../models/Driver');

// @desc    Register driver
// @route   POST /api/v1/drivers/register
// @access  Public
exports.registerDriver = asyncHandler(async (req, res, next) => {
  const {
    firstName,
    lastName,
    email,
    phone,
    idNumber,
    address,
    licenseNumber,
    licenseExpiry,
    operatingLocation,
    vehicleCategory,
    drivingExperience,
    bankName,
    accountNumber,
    termsAccepted
  } = req.body;

  // Validate terms acceptance
  if (!termsAccepted) {
    return next(new ErrorResponse('You must accept the terms and conditions', 400));
  }

  // Create temporary password (will be changed by driver later)
  const tempPassword = Math.random().toString(36).slice(-8);

  // Create driver
  const driver = await Driver.create({
    firstName,
    lastName,
    email,
    phone,
    idNumber,
    address,
    licenseNumber,
    licenseExpiry,
    operatingLocation,
    vehicleCategory,
    drivingExperience,
    bankName,
    accountNumber,
    termsAccepted,
    password: tempPassword
  });

  // TODO: Send email with temporary password

  res.status(201).json({
    success: true,
    data: {
      id: driver._id,
      firstName: driver.firstName,
      lastName: driver.lastName,
      email: driver.email,
      status: driver.status
    },
    message: 'Driver application submitted successfully'
  });
});

// @desc    Get all drivers
// @route   GET /api/v1/drivers
// @access  Private/Admin
exports.getDrivers = asyncHandler(async (req, res, next) => {
  res.status(200).json(res.advancedResults);
});

// @desc    Get single driver
// @route   GET /api/v1/drivers/:id
// @access  Private/Admin
exports.getDriver = asyncHandler(async (req, res, next) => {
  const driver = await Driver.findById(req.params.id);

  if (!driver) {
    return next(new ErrorResponse(`Driver not found with id of ${req.params.id}`, 404));
  }

  res.status(200).json({
    success: true,
    data: driver
  });
});

// @desc    Update driver
// @route   PUT /api/v1/drivers/:id
// @access  Private/Admin
exports.updateDriver = asyncHandler(async (req, res, next) => {
  let driver = await Driver.findById(req.params.id);

  if (!driver) {
    return next(new ErrorResponse(`Driver not found with id of ${req.params.id}`, 404));
  }

  driver = await Driver.findByIdAndUpdate(req.params.id, req.body, {
    new: true,
    runValidators: true
  });

  res.status(200).json({
    success: true,
    data: driver
  });
});

// @desc    Update driver status
// @route   PUT /api/v1/drivers/:id/status
// @access  Private/Admin
exports.updateDriverStatus = asyncHandler(async (req, res, next) => {
  const { status } = req.body;

  if (!['pending', 'approved', 'rejected', 'active', 'inactive'].includes(status)) {
    return next(new ErrorResponse('Invalid status value', 400));
  }

  let driver = await Driver.findById(req.params.id);

  if (!driver) {
    return next(new ErrorResponse(`Driver not found with id of ${req.params.id}`, 404));
  }

  driver = await Driver.findByIdAndUpdate(
    req.params.id,
    { status },
    {
      new: true,
      runValidators: true
    }
  );

  res.status(200).json({
    success: true,
    data: driver
  });
});

// @desc    Delete driver
// @route   DELETE /api/v1/drivers/:id
// @access  Private/Admin
exports.deleteDriver = asyncHandler(async (req, res, next) => {
  const driver = await Driver.findById(req.params.id);

  if (!driver) {
    return next(new ErrorResponse(`Driver not found with id of ${req.params.id}`, 404));
  }

  await driver.remove();

  res.status(200).json({
    success: true,
    data: {}
  });
});

// @desc    Get current logged in driver
// @route   GET /api/v1/drivers/me
// @access  Private
exports.getMe = asyncHandler(async (req, res, next) => {
  const driver = await Driver.findById(req.driver.id);

  res.status(200).json({
    success: true,
    data: driver
  });
});

// @desc    Update driver details
// @route   PUT /api/v1/drivers/updatedetails
// @access  Private
exports.updateDetails = asyncHandler(async (req, res, next) => {
  const fieldsToUpdate = {
    firstName: req.body.firstName,
    lastName: req.body.lastName,
    email: req.body.email,
    phone: req.body.phone,
    address: req.body.address
  };

  const driver = await Driver.findByIdAndUpdate(req.driver.id, fieldsToUpdate, {
    new: true,
    runValidators: true
  });

  res.status(200).json({
    success: true,
    data: driver
  });
});

// @desc    Update password
// @route   PUT /api/v1/drivers/updatepassword
// @access  Private
exports.updatePassword = asyncHandler(async (req, res, next) => {
  const driver = await Driver.findById(req.driver.id).select('+password');

  // Check current password
  if (!(await driver.matchPassword(req.body.currentPassword))) {
    return next(new ErrorResponse('Password is incorrect', 401));
  }

  driver.password = req.body.newPassword;
  await driver.save();

  sendTokenResponse(driver, 200, res);
});

// Get token from model, create cookie and send response
const sendTokenResponse = (driver, statusCode, res) => {
  // Create token
  const token = driver.getSignedJwtToken();

  const options = {
    expires: new Date(
      Date.now() + process.env.JWT_COOKIE_EXPIRE * 24 * 60 * 60 * 1000
    ),
    httpOnly: true
  };

  if (process.env.NODE_ENV === 'production') {
    options.secure = true;
  }

  res
    .status(statusCode)
    .cookie('token', token, options)
    .json({
      success: true,
      token
    });
};
