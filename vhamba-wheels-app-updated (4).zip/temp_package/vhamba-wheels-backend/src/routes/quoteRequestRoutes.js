const express = require('express');
const {
  getQuoteRequests,
  getQuoteRequest,
  createQuoteRequest,
  updateQuoteRequest,
  deleteQuoteRequest
} = require('../controllers/quoteRequestController');

const router = express.Router();

const { protect, authorize } = require('../middleware/auth');

// Public route for creating quote requests
router.route('/')
  .post(createQuoteRequest)
  .get(protect, getQuoteRequests);

// Protected routes for specific quote requests
router.route('/:id')
  .get(protect, getQuoteRequest)
  .put(protect, updateQuoteRequest)
  .delete(protect, deleteQuoteRequest);

module.exports = router;
