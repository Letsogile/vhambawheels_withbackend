const express = require('express');
const {
  getLeaseInquiries,
  getLeaseInquiry,
  createLeaseInquiry,
  updateLeaseInquiry,
  deleteLeaseInquiry
} = require('../controllers/leaseInquiryController');

const router = express.Router();

const { protect, authorize } = require('../middleware/auth');

// Public route for creating lease inquiries
router.route('/')
  .post(createLeaseInquiry)
  .get(protect, getLeaseInquiries);

// Protected routes for specific lease inquiries
router.route('/:id')
  .get(protect, getLeaseInquiry)
  .put(protect, updateLeaseInquiry)
  .delete(protect, deleteLeaseInquiry);

module.exports = router;
