const express = require('express');
const {
  processPayment,
  getPayments,
  getPayment,
  getDriverPayments,
  getVehiclePayments,
  updatePaymentStatus,
  getMyPayments
} = require('../controllers/paymentController');

const router = express.Router({ mergeParams: true });

const { protect, authorize } = require('../middleware/auth');
const advancedResults = require('../middleware/advancedResults');
const Payment = require('../models/Payment');

router
  .route('/')
  .post(processPayment)
  .get(
    protect,
    authorize('admin'),
    advancedResults(Payment, [
      { path: 'driver', select: 'firstName lastName email' },
      { path: 'vehicle', select: 'make model year licensePlate' }
    ]),
    getPayments
  );

router
  .route('/me')
  .get(protect, getMyPayments);

// If route includes driverId parameter, get payments for that driver
router
  .route('/')
  .get(protect, authorize('admin'), getDriverPayments);

// If route includes vehicleId parameter, get payments for that vehicle
router
  .route('/')
  .get(protect, authorize('admin'), getVehiclePayments);

router
  .route('/:id')
  .get(protect, authorize('admin'), getPayment);

router
  .route('/:id/status')
  .put(protect, authorize('admin'), updatePaymentStatus);

module.exports = router;
