const express = require('express');
const {
  registerDriver,
  getDrivers,
  getDriver,
  updateDriver,
  updateDriverStatus,
  deleteDriver,
  getMe,
  updateDetails,
  updatePassword
} = require('../controllers/driverController');

const router = express.Router();

const { protect, authorize } = require('../middleware/auth');
const advancedResults = require('../middleware/advancedResults');
const Driver = require('../models/Driver');

// Routes for driver payments
const paymentRouter = require('./paymentRoutes');
router.use('/:driverId/payments', paymentRouter);

router
  .route('/register')
  .post(registerDriver);

router
  .route('/me')
  .get(protect, getMe);

router
  .route('/updatedetails')
  .put(protect, updateDetails);

router
  .route('/updatepassword')
  .put(protect, updatePassword);

router
  .route('/')
  .get(
    protect,
    authorize('admin'),
    advancedResults(Driver),
    getDrivers
  );

router
  .route('/:id')
  .get(protect, authorize('admin'), getDriver)
  .put(protect, authorize('admin'), updateDriver)
  .delete(protect, authorize('admin'), deleteDriver);

router
  .route('/:id/status')
  .put(protect, authorize('admin'), updateDriverStatus);

module.exports = router;
