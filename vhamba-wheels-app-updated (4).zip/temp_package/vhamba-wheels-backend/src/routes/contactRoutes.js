const express = require('express');
const {
  getContactMessages,
  getContactMessage,
  createContactMessage,
  updateContactMessage,
  deleteContactMessage
} = require('../controllers/contactController');

const router = express.Router();

const { protect, authorize } = require('../middleware/auth');

// Public route for creating contact messages
router.route('/')
  .post(createContactMessage)
  .get(protect, authorize('admin'), getContactMessages);

// Protected routes for specific contact messages
router.route('/:id')
  .get(protect, authorize('admin'), getContactMessage)
  .put(protect, authorize('admin'), updateContactMessage)
  .delete(protect, authorize('admin'), deleteContactMessage);

module.exports = router;
