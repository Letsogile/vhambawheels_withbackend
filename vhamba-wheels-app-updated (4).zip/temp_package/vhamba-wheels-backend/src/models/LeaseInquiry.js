const mongoose = require('mongoose');

const LeaseInquirySchema = new mongoose.Schema({
  user: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'User'
  },
  location: {
    type: mongoose.Schema.Types.ObjectId,
    ref: 'Location',
    required: [true, 'Please select a location']
  },
  startDate: {
    type: Date,
    required: [true, 'Please add a start date']
  },
  leasePeriod: {
    type: String,
    enum: ['1 Month', '3 Months', '6 Months', '12 Months'],
    required: [true, 'Please select a lease period']
  },
  status: {
    type: String,
    enum: ['pending', 'processed', 'completed'],
    default: 'pending'
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('LeaseInquiry', LeaseInquirySchema);
