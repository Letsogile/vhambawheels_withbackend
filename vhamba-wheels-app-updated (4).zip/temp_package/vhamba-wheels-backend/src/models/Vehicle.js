const mongoose = require('mongoose');

const VehicleSchema = new mongoose.Schema({
  name: {
    type: String,
    required: [true, 'Please add a vehicle name'],
    trim: true
  },
  class: {
    type: String,
    enum: ['economy', 'premium', 'suv'],
    required: [true, 'Please specify vehicle class']
  },
  dailyRate: {
    type: Number,
    required: [true, 'Please add a daily rate']
  },
  fuelType: {
    type: String,
    required: [true, 'Please add fuel type']
  },
  transmission: {
    type: String,
    required: [true, 'Please add transmission type']
  },
  seats: {
    type: Number,
    required: [true, 'Please add number of seats']
  },
  rating: {
    type: Number,
    default: 0
  },
  imageUrl: {
    type: String,
    required: [true, 'Please add an image URL']
  },
  available: {
    type: Boolean,
    default: true
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  updatedAt: {
    type: Date,
    default: Date.now
  }
});

module.exports = mongoose.model('Vehicle', VehicleSchema);
