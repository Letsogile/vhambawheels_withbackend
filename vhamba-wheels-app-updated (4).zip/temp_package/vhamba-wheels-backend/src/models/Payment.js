const mongoose = require('mongoose');

// Payment schema
const PaymentSchema = new mongoose.Schema({
  paymentType: {
    type: String,
    required: [true, 'Please select a payment type'],
    enum: ['lease_payment', 'deposit', 'maintenance', 'insurance', 'other']
  },
  vehicleId: {
    type: String,
    trim: true
  },
  amount: {
    type: Number,
    required: [true, 'Please enter the payment amount'],
    min: [0.01, 'Amount must be at least 0.01']
  },
  processingFee: {
    type: Number,
    default: 5.00
  },
  totalAmount: {
    type: Number
  },
  cardholderName: {
    type: String,
    required: [true, 'Please provide the cardholder name'],
    trim: true
  },
  // Only store last 4 digits for reference
  lastFourDigits: {
    type: String,
    trim: true
  },
  paymentStatus: {
    type: String,
    enum: ['pending', 'completed', 'failed', 'refunded'],
    default: 'pending'
  },
  transactionId: {
    type: String,
    trim: true
  },
  driver: {
    type: mongoose.Schema.ObjectId,
    ref: 'Driver'
  },
  vehicle: {
    type: mongoose.Schema.ObjectId,
    ref: 'Vehicle'
  },
  createdAt: {
    type: Date,
    default: Date.now
  }
});

// Calculate total amount before saving
PaymentSchema.pre('save', function(next) {
  this.totalAmount = this.amount + this.processingFee;
  next();
});

module.exports = mongoose.model('Payment', PaymentSchema);
