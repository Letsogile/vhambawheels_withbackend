const mongoose = require('mongoose');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');

// Driver schema for onboarding
const DriverSchema = new mongoose.Schema({
  // Personal Information
  firstName: {
    type: String,
    required: [true, 'Please provide your first name'],
    trim: true
  },
  lastName: {
    type: String,
    required: [true, 'Please provide your last name'],
    trim: true
  },
  email: {
    type: String,
    required: [true, 'Please provide an email'],
    unique: true,
    match: [
      /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/,
      'Please provide a valid email'
    ]
  },
  phone: {
    type: String,
    required: [true, 'Please provide a phone number'],
    trim: true
  },
  idNumber: {
    type: String,
    required: [true, 'Please provide your ID number'],
    unique: true,
    trim: true
  },
  address: {
    type: String,
    required: [true, 'Please provide your physical address']
  },
  
  // Driver & Vehicle Details
  licenseNumber: {
    type: String,
    required: [true, 'Please provide your driver\'s license number'],
    unique: true,
    trim: true
  },
  licenseExpiry: {
    type: Date,
    required: [true, 'Please provide your license expiry date']
  },
  operatingLocation: {
    type: String,
    required: [true, 'Please select your preferred operating location'],
    enum: ['Pretoria', 'Cape Town', 'Both Locations']
  },
  vehicleCategory: {
    type: String,
    enum: ['Economy', 'Compact', 'SUV', 'Luxury', '']
  },
  drivingExperience: {
    type: Number,
    min: 0
  },
  
  // Banking & Preferences
  bankName: {
    type: String,
    required: [true, 'Please provide your bank name'],
    trim: true
  },
  accountNumber: {
    type: String,
    required: [true, 'Please provide your account number'],
    trim: true
  },
  
  // Application Status
  status: {
    type: String,
    enum: ['pending', 'approved', 'rejected', 'active', 'inactive'],
    default: 'pending'
  },
  
  // System Fields
  password: {
    type: String,
    minlength: 6,
    select: false
  },
  resetPasswordToken: String,
  resetPasswordExpire: Date,
  termsAccepted: {
    type: Boolean,
    default: false
  },
  createdAt: {
    type: Date,
    default: Date.now
  },
  assignedVehicle: {
    type: mongoose.Schema.ObjectId,
    ref: 'Vehicle'
  }
});

// Encrypt password using bcrypt
DriverSchema.pre('save', async function(next) {
  if (!this.isModified('password')) {
    next();
  }

  const salt = await bcrypt.genSalt(10);
  this.password = await bcrypt.hash(this.password, salt);
});

// Sign JWT and return
DriverSchema.methods.getSignedJwtToken = function() {
  return jwt.sign({ id: this._id }, process.env.JWT_SECRET, {
    expiresIn: process.env.JWT_EXPIRE
  });
};

// Match user entered password to hashed password in database
DriverSchema.methods.matchPassword = async function(enteredPassword) {
  return await bcrypt.compare(enteredPassword, this.password);
};

module.exports = mongoose.model('Driver', DriverSchema);
