# Vhamba Wheels Application Documentation

## Overview

Vhamba Wheels is a full-stack application for a vehicle leasing platform focused on e-hailing services. The application allows users to browse available vehicles, submit lease inquiries, request quotes, and contact the company. The platform has been updated to include driver onboarding and payment processing features.

## Application Structure

### Frontend (React/TypeScript)

The frontend is built with React and TypeScript, using Tailwind CSS for styling. It follows a component-based architecture with the following structure:

```
src/
├── components/       # Reusable UI components
│   ├── forms/        # Form components
│   ├── layout/       # Layout components (Navbar, Footer)
│   ├── vehicles/     # Vehicle-related components
│   ├── locations/    # Location-related components
│   ├── services/     # Service-related components
│   └── testing/      # Test components
├── contexts/         # React contexts for state management
├── pages/            # Page components
├── services/         # API service layer
└── utils/            # Utility functions
```

### Backend (Node.js/Express)

The backend is built with Node.js and Express, using MongoDB as the database. It follows a modular architecture with the following structure:

```
src/
├── config/           # Configuration files
├── controllers/      # Request handlers
├── middleware/       # Express middleware
├── models/           # MongoDB models
├── routes/           # API routes
├── services/         # Business logic
└── utils/            # Utility functions
```

## New Features

### 1. Driver Onboarding

The driver onboarding feature allows potential drivers to apply to become contractors for Vhamba Logistics. The onboarding process is divided into three steps:

#### Step 1: Personal Information
- First name and last name
- Email address
- Phone number
- ID number
- Physical address

#### Step 2: Driver & Vehicle Details
- Driver's license number
- License expiry date
- Preferred operating location
- Vehicle category preference
- Driving experience

#### Step 3: Banking & Preferences
- Bank name
- Account number
- Terms and conditions acceptance

After submission, the application is stored in the database with a status of "pending" for admin review.

### 2. Payment Portal

The payment portal allows drivers to make various types of payments related to their vehicle leases:

#### Payment Types
- Lease Payment
- Security Deposit
- Maintenance Fee
- Insurance Premium
- Other Payment

#### Payment Process
1. User selects payment type
2. User enters vehicle ID (optional)
3. User enters payment amount
4. User enters credit card details
5. System adds a processing fee
6. Payment is processed and stored in the database

## API Endpoints

### Driver Onboarding API

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/drivers/register` | POST | Register a new driver application |
| `/api/drivers` | GET | Get all drivers (admin only) |
| `/api/drivers/:id` | GET | Get a specific driver (admin only) |
| `/api/drivers/:id` | PUT | Update a driver (admin only) |
| `/api/drivers/:id/status` | PUT | Update driver status (admin only) |
| `/api/drivers/me` | GET | Get current driver profile |
| `/api/drivers/updatedetails` | PUT | Update driver details |
| `/api/drivers/updatepassword` | PUT | Update driver password |

### Payment API

| Endpoint | Method | Description |
|----------|--------|-------------|
| `/api/payments` | POST | Process a payment |
| `/api/payments` | GET | Get all payments (admin only) |
| `/api/payments/:id` | GET | Get a specific payment (admin only) |
| `/api/payments/:id/status` | PUT | Update payment status (admin only) |
| `/api/payments/me` | GET | Get current driver's payments |
| `/api/drivers/:driverId/payments` | GET | Get payments for a specific driver (admin only) |
| `/api/vehicles/:vehicleId/payments` | GET | Get payments for a specific vehicle (admin only) |

## Setup Instructions

### Prerequisites
- Node.js (v14 or higher)
- MongoDB (v4 or higher)
- npm or pnpm

### Backend Setup
1. Navigate to the `vhamba-wheels-backend` directory
2. Install dependencies: `npm install`
3. Create a `.env` file with the following variables:
   ```
   NODE_ENV=development
   PORT=5000
   MONGO_URI=mongodb://localhost:27017/vhamba-wheels
   JWT_SECRET=your_jwt_secret
   JWT_EXPIRE=30d
   ```
4. Start the development server: `npm run dev`

### Frontend Setup
1. Navigate to the `vhamba-wheels-frontend` directory
2. Install dependencies: `npm install` or `pnpm install`
3. Create a `.env` file with the following variables:
   ```
   REACT_APP_API_URL=http://localhost:5000/api
   ```
4. Start the development server: `npm start`

## Deployment

### Backend Deployment
1. Set up a MongoDB database (Atlas or self-hosted)
2. Deploy the Node.js application to a hosting service (Heroku, AWS, etc.)
3. Set the environment variables in the hosting service
4. Ensure CORS is properly configured for your frontend domain

### Frontend Deployment
1. Build the production version: `npm run build`
2. Deploy the build folder to a static hosting service (Vercel, Netlify, etc.)
3. Ensure the API URL environment variable is set correctly

## Testing

The application includes comprehensive test components for both the onboarding form and payment portal. These tests verify:

- Form validation
- API integration
- Error handling
- Loading states
- Success handling
- Responsive design

## Troubleshooting

### Common Issues

1. **API Connection Errors**
   - Check that the backend server is running
   - Verify the API URL in the frontend .env file
   - Check for CORS issues in the browser console

2. **Database Connection Issues**
   - Verify MongoDB connection string
   - Check MongoDB Atlas network access settings
   - Ensure database user has correct permissions

3. **Authentication Issues**
   - Check JWT secret and expiration settings
   - Verify token is being stored correctly in localStorage
   - Check that protected routes are using the auth middleware

## Support

For technical support, please contact:
- Email: support@vhambalogistics.co.za
- Phone: +27 12 345 6789
